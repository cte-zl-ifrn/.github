<?php

$plugins = array(
        'doubleScroll' => array('files' => array('jquery.doubleScroll.js')),
        'fxHeader'     => array('files' => array('fxHeader_0.6.js')),
        'jquery-1.7.2.min' => array('files' => array('jquery-1.7.2.min.js')),
        'ui.core'      => array('files' => array('ui/jquery.ui.core.js')),
        'ui.widget'    => array('files' => array('ui/jquery.ui.widget.js')),
        'ui.mouse'     => array('files' => array('ui/jquery.ui.mouse.js')),
        'ui.draggable' => array('files' => array('ui/jquery.ui.draggable.js')),
);

        