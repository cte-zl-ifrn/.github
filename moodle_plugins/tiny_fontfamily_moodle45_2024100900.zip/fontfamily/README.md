# moodle-tiny_fontfamily
Tiny editor font family plugin.

Plugin allows users to change their text's font family.
