<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Plugin strings are defined here.
 *
 * @package     profilefield_brasilufmunicipio
 * @category    string
 * @copyright   2021 Daniel Neis Araujo <daniel@adapta.online>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['availableufs'] = 'Available UFs';
$string['availableufs_desc'] = 'Select the UFs you want the user to be able to select from';
$string['errorunavailableuf'] = 'This UF is not available. Please, select another UF.';
$string['municipio'] = 'Município';
$string['municipio_help'] = 'Select UF to fill Município.';
$string['pluginname'] = 'Brasil UF e Município';
$string['showall'] = 'Show all UFs but validate selected value.';
$string['uf'] = 'UF';
