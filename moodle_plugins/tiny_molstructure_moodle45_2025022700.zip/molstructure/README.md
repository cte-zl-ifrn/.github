Moodle tiny plugin allowing to add a chemical structure or reaction as an image without the need of any licence.

## Authors
-Louis Plyer louis.plyer@unistra.fr
- Céline Perves cperves@unistra.fr
- Gilles Marcou g.marcou@unistra.fr
- Alexandre Varnek varnek@unistra.fr

## Licence

GNU GPL v3 or later 
