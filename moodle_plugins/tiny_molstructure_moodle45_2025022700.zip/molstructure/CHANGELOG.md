# Change log
* 27/02/2025 new version Moodle 4.5 version with various views : 2D, 3D, Spectrum 
* 19/03/2024 tiny version of previous atto molstructure plugin