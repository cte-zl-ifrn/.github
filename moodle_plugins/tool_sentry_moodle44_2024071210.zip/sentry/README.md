# SENTRY
Sentry is a Open Source, Self-hosted and cloud-based application performance monitoring & error tracking that helps software teams see clearer, solve quicker, & learn continuously. Disponible in sentry.io.
# tool_sentry
Simple sentry plugin to moodle TESTED in moodle 4.x.

It should work on the previous version but I did not test or configured it yet, it requires PHP>=7.3 for now.


License
=======

GNU GPL v3 or later. http://www.gnu.org/copyleft/gpl.html