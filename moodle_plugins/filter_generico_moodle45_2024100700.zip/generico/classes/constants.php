<?php
/**
 * Created by PhpStorm.
 * User: ishineguy
 * Date: 2018/06/16
 * Time: 19:31
 */

namespace filter_generico;

class constants {
    const MOD_FRANKY = 'filter_generico';
}