Release Notes
##### 1.0.4 (Build 2024042600)
New features / improvements:

* add sorting
* some langfilefixes

##### 1.0.3 (Build 2024030102)
New features / improvements:

* add this file CHANGES.md for documentation


Big fixes:

* fix linter issues
* remove unused code



##### 1.0.2 (Build 2024030101)
New features / improvements:

* add this file CHANGES.md for documentation
* add workflow moodle-releases.yml


Big fixes:

* 


##### 1.0.1 (Build 2024030101)
New features / improvements:

*


Big fixes:

* grunt, codechecker, issues, ...



##### 1.0.1 (Build 2024030101)
New features / improvements:

*


Big fixes:

* grunt, codechecker, issues, ...


##### 1.0.0 (Build 2024021501)
New features / improvements:

* inital beta


Big fixes:

* 
