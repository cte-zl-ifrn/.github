The conditional profile field plugin is an advanced version of the dropdown menu profile field type in which you can decide to hide/show some other profile fields or even make them required based on the value selected for this field.

This allows you designing dynamic signup/profile pages.