{
    "moodle-atto_morefontcolors-button": {
        "requires": ["node"]
    }
}
