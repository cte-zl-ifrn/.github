This plugin extends the new TinyMCE editor introduced in Moodle 4.1 by adding word limit information to the editor's status bar.

Currently the plugin checks for maximum word limits in:
- Online submissions in assignments
- Essay questions ins within a quiz
