---
name: Question
about: Question about the theme
title: ''
labels: Question
assignees: gjb2048

---

Please use this when you have a general question about the theme that is not a bug, enhancement / improvement or support.

**Versions (please complete the following information):**
 - Moodle: [e.g. 4.1]
 - Theme: [e.g. 401.1.0]
 - Browser and version [e.g. Chrome Version 108.0.5359.125 (Official Build) (64-bit) on Windows 10]
