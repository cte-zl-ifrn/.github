{
    "moodle-atto_morebackcolors-button": {
        "requires": ["node"]
    }
}
